package uk.co.marcoratto.file;

import java.io.File;
import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.io.filefilter.WildcardFileFilter;

import uk.co.marcoratto.apache.ssh.Directory;
import uk.co.marcoratto.util.RelativePath;

public class Folder {

	  private List<File> listOfFiles = new ArrayList<File>();
	  private List<Folder> listOfDirectories = new ArrayList<Folder>();
	  private File root = null;
	  private String pattern = null;
	  		
	  public File getFolder() {
		  return this.root;
	  }
	  
	  private boolean isEmpty() throws FileNotFoundException {
		  FileFilter fileFilter = new WildcardFileFilter(pattern);
		  return (this.root.listFiles(fileFilter).length == 0);
	  }
	  
	    public Iterator<Folder> folderIterator() {
	        return this.listOfDirectories.iterator();
	    }

	    /**
	     * Get an iterator over the files.
	     * @return an iterator
	     */
	    public Iterator<File> filesIterator() {
	        return this.listOfFiles.iterator();
	    }
	    
	  public Folder (File directory) throws FileNotFoundException {
		  validateDirectory(directory);
		  this.root = directory;
	  }
	  
	  public void scan (String wildcards) throws FileNotFoundException {
		  this.pattern = wildcards;		  		  
		  this.scan(this.root);
	  }
	  
	  private void scan (File aFolder) throws FileNotFoundException {
			FileFilter fileFilter = new WildcardFileFilter(pattern);
			File[] files = aFolder.listFiles(fileFilter);
		    for(File file : files) {
		        this.listOfFiles.add(file); 
		    }		  	    

		    File[] filesAndDirs = aFolder.listFiles();		    
		    for(File file : filesAndDirs) {
			  if (this.isValidateDirectory(file)) {
				Folder f = new Folder(file);
				f.scan(this.pattern);
			    this.listOfDirectories.add(f);				  
			}
		  }		  		 
	  }	  
	  
	  private boolean isValidateDirectory(File aDirectory) throws FileNotFoundException {
		    if (aDirectory == null) {
		      return false;
		    }
		    if (!aDirectory.exists()) {
		    	return false;
		    }
		    if (!aDirectory.isDirectory()) {
		    	return false;
		    }
		    if (!aDirectory.canRead()) {
		    	return false;
		    }	  
		    return true;
	  }

	  public void navigate(PrintStream ps) {
	    for (Iterator<Folder> i = this.folderIterator(); i.hasNext();) {
	        Folder current = (Folder) i.next();	        
	        ps.println(RelativePath.getRelativePath(root, current.getFolder()));
	        for (Iterator<File> fileIt = current.filesIterator(); fileIt.hasNext();) {
	        	ps.println(fileIt.next());
	        }
	        current.navigate(ps);
	    }		  
	  }

	  public List<Directory> toDirectory(Directory d) {
			List<Directory> listOfDirectory = new ArrayList<Directory>();

		    for (Iterator<Folder> i = this.folderIterator(); i.hasNext();) {
		        Folder current = (Folder) i.next();	   
		        new Directory(current.getFolder());
		        for (Iterator<File> fileIt = current.filesIterator(); fileIt.hasNext();) {
		        	d.addFile(fileIt.next());
		        }
		        listOfDirectory.addAll(current.toDirectory(d));
		    }		  
		    return listOfDirectory;
	  }
	  
	  private void validateDirectory(File aDirectory) throws FileNotFoundException {
		    if (aDirectory == null) {
		      throw new IllegalArgumentException("Directory should not be null.");
		    }
		    if (!aDirectory.exists()) {
		      throw new FileNotFoundException("Directory does not exist: " + aDirectory);
		    }
		    if (!aDirectory.isDirectory()) {
		      throw new IllegalArgumentException("Is not a directory: " + aDirectory);
		    }
		    if (!aDirectory.canRead()) {
		      throw new IllegalArgumentException("Directory cannot be read: " + aDirectory);
		    }	  
	  }
} 
