package uk.co.marcoratto.file;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.StringTokenizer;

import org.apache.commons.io.filefilter.WildcardFileFilter;

import uk.co.marcoratto.apache.ssh.Directory;
import uk.co.marcoratto.util.RelativePath;

public class DirectoryTree {

	private File parent;
    private Directory root;
    private ArrayList<File> files;
    private Set<Directory> childDirectories;
    
    public DirectoryTree() {
        this.childDirectories = new LinkedHashSet<Directory>();
        this.files = new ArrayList<File>();    	
    }
    
	public void scan(File aDirectory, String pattern, boolean recursive) {
		this.root = new Directory(aDirectory);
		this.parent = null;
		this.search(this.root, pattern, recursive);
	}

    public static String[] getPath(String thePath) {
        StringTokenizer tokenizer = new StringTokenizer(thePath, File.separator);
        String[] path = new String[tokenizer.countTokens()];
        int i = 0;
        while (tokenizer.hasMoreTokens()) {
            path[i] = tokenizer.nextToken();
            i++;
        }
        return path;
    }	
    
	private void search(Directory root, String pattern, boolean recursive) {
		FileFilter fileFilter = new WildcardFileFilter(pattern);
		File[] files = root.getDirectory().listFiles(fileFilter);
		for (int i = 0; i < files.length; i++) {
			this.files.add(files[i]);	
		}
		File[] listAll = root.getDirectory().listFiles();
		for (int i=0; i<listAll.length; i++) {
			if (listAll[i].isDirectory()) {
				this.childDirectories.add(new Directory(listAll[i]));
			} 
		}			
		if (recursive) {
			String[] list = root.getDirectory().list();
			for (int i = 0; i < list.length; i++) {
				this.search(new Directory(new File(root.getDirectory(), list[i])), pattern, recursive);						
			}				
		}
	}
	
    public Iterator<Directory> directoryIterator() {
        return this.childDirectories.iterator();
    }

    /**
     * Get an iterator over the files.
     * @return an iterator
     */
    public Iterator<File> filesIterator() {
        return files.iterator();
    }    
    
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		DirectoryTree dt = new DirectoryTree();
		dt.scan(new File("."), "*.txt", true);
		for (Iterator<File> fileIt = dt.filesIterator(); fileIt.hasNext();) {
			System.out.println(RelativePath.getRelativePath(new File("."), fileIt.next()));
		}
	}

}
