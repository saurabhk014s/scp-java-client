/*
 * Copyright (C) 2011 Marco Ratto
 *
 * This file is part of the project scp-java-client.
 *
 * scp-java-client is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 *
 * scp-java-client is free software; you can redistribute it and/or modify
 * it under the terms of the the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
package uk.co.marcoratto.util;

import java.io.IOException;
import javax.naming.InitialContext;
import javax.naming.Context;

import java.io.File;

/**
 * La classe gestisce il file di Properties dell'infrastruttura <code>infrastruttura.properties</code>. &egrave; un'implementazione del Pattern Singleton, per cui il file &egrave; letto solo al momento della creazione dell'istanza della classe.
 * <BR>Mentre il nome del file di properties &egrave; fisso (<b>infrastruttura.properties</b>), il path &egrave; determinato come segue:
 * <BR>- in prima istanza si cerca la variabile di <i>JVM</i> con nome <b>infrastruttura_properties_path</b>;
 * <BR>- se la variabile non viene trovata, si cerca il path tramite una variabile di ambiente del <code>Context</code> sempre con nome <b>infrastruttura_properties_path</b>;
 * <BR>- se anche la variabile del <code>Context</code> non esiste, il path di default <b>/</b> (root).
 * @author Marco Ratto
 */
public class PropertiesManager extends AbstractPropertiesManager {
		
	protected final static String USER_HOME = System.getProperty("user.home") + "/.scp";
	  private static PropertiesManager instance = null;

	  // nome jndi del file di properties
	  public static final String FILENAME_URL = "url/scp_config_file";

	  // nome di default del file di properties
	  public static final String DEFAULT_PROPERTIES_FILE_NAME = "scp_config_file.properties";

	 // nome della property contenente il nome del file di properties
	  private static final String FILENAME_PROPERTYNAME = "scp_config_file";
	
  /**
   * Costruttore della classe. Acquisisce i parametri dal file di Properties.
   * @exception java.io.IOException*/
  protected PropertiesManager() throws PropertiesManagerException {
  /**
    String filename = getPropertiesFilename();
    readFileProperties(filename);
    **/
    super();
    readFileProperties();
  }

  /**
   * Costruttore della classe. Acquisisce i parametri dal file di Properties
   * identificato da propertiesPath
   * @param propertiesPath File
   * @throws IOException
   */
  protected PropertiesManager(File propertiesPath) throws PropertiesManagerException {
    super();
    readFileProperties(propertiesPath);
  }

  /**
   * Il metodo ritorna la stringa contenente il <i>path</i> ed il nome del file di <code>properties</code>.
   * Il nome del file di properties &egrave; determinato come segue:
   * <BR>- in prima istanza si cerca il path nella variabile di <i>JVM</i> con nome <b>infrastruttura_properties_path</b>;
   * <BR>- se la variabile non viene trovata, si cerca il path tramite una variabile di ambiente del <code>Context</code> sempre con nome <b>infrastruttura_properties_path</b>;
   * <BR>- se anche la variabile del <code>Context</code> non esiste, il path di default &egrave; <b>/</b> (root del classloader).
   * <BR>- poi si cerca il filename nella variabile di <i>JVM</i> con nome <b>infrastruttura_properties_filename</b>;
   * <BR>- se la variabile non viene trovata, si cerca il filename tramite una variabile di ambiente del <code>Context</code> sempre con nome <b>infrastruttura_properties_filename</b>;
   * <BR>- se anche la variabile del <code>Context</code> non esiste, il filename di default &egrave; <b>infrastruttura.properties</b>.
   * @return String filename
   */
  protected String getPropertiesFilename() {
    String filename = null;
    InitialContext ic = null;
    Context ctx = null;

    // ricerca del filename...
    try {
		File f = new File(USER_HOME, DEFAULT_PROPERTIES_FILE_NAME);
		logger.info("Try to read from file " + f.getAbsolutePath());
		if (f.exists()) {
			filename = f.getAbsolutePath();
			logger.info("OK");
		} else {
	      // ricerca del filepath come parametro della JVM (-d ...)
	      filename = System.getProperty(FILENAME_PROPERTYNAME);
		  logger.info("Try to read from -D" + PropertiesManager.FILENAME_PROPERTYNAME + "=" + filename);
	      if (filename != null) {
	    	  logger.info("OK");
	      } else {
	        // ricerca nel context JNDI
	        ic = new InitialContext();
	        ctx = (Context)ic.lookup("java:comp/env");
	        filename = (String) ctx.lookup(FILENAME_PROPERTYNAME);
	        if (filename != null) {
	        	logger.info("OK");
	        } else {
	            filename = DEFAULT_PROPERTIES_FILE_NAME;
	            logger.info("OK");
	        }
	      }			
		} 
		logger.info("filename=" + filename);
    } catch (Throwable e) {
      // in caso di errore di assegna il default
      filename = DEFAULT_PROPERTIES_FILE_NAME;
      logger.error(e.getMessage(), e);
    }
    return filename;
  }

  public void reset() {
	  instance = null;
  }
  
  public static PropertiesManager getInstance() throws PropertiesManagerException {
    if (instance == null) {
      synchronized(PropertiesManager.class) {
        if (instance == null) {
          instance = new PropertiesManager();
        }
      }
    }
    return instance;
  }

  /**
   * Il metodo restituisce il valore della property identificata dal parametro <code>key</code>. Se la property non esiste, il metodo ritorna <code>null</code>.
   * @param key String
   * @return String
   */
  public String getProperty(String key) {
    String value = prop.getProperty(key);
    logger.info(key + "=" + value);
    return value;
  }

  /**
   * Il metodo restituisce il valore della property identificata dal parametro <code>key</code>. Se la property non esiste, il metodo ritorna il parametro <code>defaultValue</code>.
   * @param key String
   * @param defaultValue String
   * @return String
   */
  public String getProperty(String key, String defaultValue) {
	String value = prop.getProperty(key, defaultValue);
	logger.info(key + "=" + value);
	return value;
  }
  
  public int getProperty(String key, int defaultValue) {
	    return Integer.parseInt(this.getProperty(key, String.valueOf(defaultValue)), 10);
  }
  
  public boolean getProperty(String key, boolean defaultValue) {
	    return this.getProperty(key, String.valueOf(defaultValue)).equalsIgnoreCase("true");
}  
  
  protected String getFileURL() {
    return FILENAME_URL;
  }

  protected String getDefaultFileName() {
    return DEFAULT_PROPERTIES_FILE_NAME;
  }

  protected String getFilenamePropertyName() {
    return FILENAME_PROPERTYNAME;
  }

}
