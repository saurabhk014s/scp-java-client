package uk.co.marcoratto.apache.ssh;

import org.apache.log4j.Logger;

public class ScpException extends Exception {

	private static Logger logger = Logger.getLogger("uk.co.marcoratto.scp");

	/**
	 * 
	 */
	private static final long serialVersionUID = -8081682431340732511L;

	public ScpException(String s) {
		super(s);
	}

	public ScpException(Throwable t) {
		super(t);
	}

	public ScpException(String s, Exception e) {
		super(s, e);
		logger.error(s, e);
	}

	public ScpException(Exception e) {
		super(e);
		logger.error(e.getMessage(), e);
	}
	
    public static ScpException exactlyOne(String[] attrs) {
        return exactlyOne(attrs, null);
    }
	
    public static ScpException exactlyOne(String[] attrs, String alt) {
        StringBuffer buf = new StringBuffer("Exactly one of ").append(
                '[').append(attrs[0]);
        for (int i = 1; i < attrs.length; i++) {
            buf.append('|').append(attrs[i]);
        }
        buf.append(']');
        if (alt != null) {
            buf.append(" or ").append(alt);
        }
        return new ScpException(buf.append(" is required.").toString());
    }

}
