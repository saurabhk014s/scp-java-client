/*
 *  Licensed to the Apache Software Foundation (ASF) under one or more
 *  contributor license agreements.  See the NOTICE file distributed with
 *  this work for additional information regarding copyright ownership.
 *  The ASF licenses this file to You under the Apache License, Version 2.0
 *  (the "License"); you may not use this file except in compliance with
 *  the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */

package uk.co.marcoratto.apache.ssh;

import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

import java.io.FileFilter;
import java.io.IOException;
import java.io.File;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.apache.log4j.Logger;

import uk.co.marcoratto.file.maketree.MakeTree;
import uk.co.marcoratto.file.maketree.MakeTreeException;
import uk.co.marcoratto.file.maketree.MakeTreeInterface;
import uk.co.marcoratto.scp.listeners.Listener;
import uk.co.marcoratto.util.Utility;

/**
 * Ant task for sending files to remote machine over ssh/scp.
 *
 * @since Ant 1.6
 */
public class Scp extends SSHBase implements MakeTreeInterface {
	
	private List<Directory> listOfDirectory = new ArrayList<Directory>();
	
    private Directory current;
    private File from = null;
    private String chmodFile = null;
    private String chmodDirectory = null;
    
	private static Logger logger = Logger.getLogger("uk.co.marcoratto.scp");
	
    private static final String[] FROM_ATTRS = {
        "file", "localfile", "remotefile" };

    private static final String[] TO_ATTRS = {
        "todir", "localtodir", "remotetodir", "localtofile", "remotetofile" };

    private String fromUri;
    private String toUri;
    private boolean preserveLastModified = false;
    private boolean isFromRemote, isToRemote;
    private boolean isSftp = false;
    private boolean isRecursive = false;
    private boolean askPassword = false;
    private int numberOfRetry = 0;
    private Listener scpLogger = null;
    
    public Scp(Listener anScpLogger) {
    	super();
    	this.scpLogger = anScpLogger;
    }

    /**
     * Sets the file to be transferred.  This can either be a remote
     * file or a local file.  Remote files take the form:<br>
     * <i>user:password@host:/directory/path/file.example</i><br>
     * Files to transfer can also include a wildcard to include all
     * files in a remote directory.  For example:<br>
     * <i>user:password@host:/directory/path/*</i><br>
     * @param aFromUri a string representing the file to transfer.
     * @throws ScpException 
     */
    public void setFile(String aFromUri) throws ScpException {
    	if (aFromUri != null) {
            setFromUri(aFromUri);
            this.isFromRemote = isRemoteUri(this.fromUri);   		
    	}
    }

    /**
     * Sets the location where files will be transferred to.
     * This can either be a remote directory or a local directory.
     * Remote directories take the form of:<br>
     * <i>user:password@host:/directory/path/</i><br>
     * This parameter is required.

     * @param aToUri a string representing the target of the copy.
     * @throws ScpException 
     */
    public void setTodir(String aToUri) throws ScpException {
    	if (aToUri != null) {
    		setToUri(aToUri);
            this.isToRemote = isRemoteUri(this.toUri);
    	}
    }

    /**
     * Similiar to {@link #setFile setFile} but explicitly states that
     * the file is a local file.  This is the only way to specify a
     * local file with a @ character.
     * @param aFromUri a string representing the source of the copy.
     * @throws ScpException 
     * @since Ant 1.6.2
     */
    public void setLocalFile(String aFromUri) throws ScpException {
    	if (aFromUri != null) {
            setFromUri(aFromUri);
            this.isFromRemote = false;    		
    	}
    }

    /**
     * Similiar to {@link #setFile setFile} but explicitly states that
     * the file is a remote file.
     * @param aFromUri a string representing the source of the copy.
     * @throws ScpException 
     * @since Ant 1.6.2
     */
    public void setRemoteFile(String aFromUri) throws ScpException {
    	if (aFromUri != null) {
    		validateRemoteUri("remoteFile", aFromUri);
            setFromUri(aFromUri);
            this.isFromRemote = true;
    	}
     }

    /**
     * Similiar to {@link #setTodir setTodir} but explicitly states
     * that the directory is a local.  This is the only way to specify
     * a local directory with a @ character.
     * @param aToUri a string representing the target of the copy.
     * @throws ScpException 
     * @since Ant 1.6.2
     */
    public void setLocalTodir(String aToUri) throws ScpException {
    	if (aToUri != null) {
            setToUri(aToUri);
            this.isToRemote = false;    		
    	}
    }

    /**
     * Sets flag to determine if file timestamp from
     * remote system is to be preserved during copy.
     * @since Ant 1.8.0
     */
    public void setPreservelastmodified(boolean yesOrNo) {
    	this.preserveLastModified = yesOrNo;
    }    

    /**
     * Similiar to {@link #setTodir setTodir} but explicitly states
     * that the directory is a remote.
     * @param aToUri a string representing the target of the copy.
     * @throws ScpException 
     * @since Ant 1.6.2
     */
    public void setRemoteTodir(String aToUri) throws ScpException {
    	if (aToUri != null) {
            validateRemoteUri("remoteToDir", aToUri);
            setToUri(aToUri);
            this.isToRemote = true;    		
    	}
    }

    private static void validateRemoteUri(String type, String aToUri) throws ScpException {
    	if (!isRemoteUri(aToUri)) {
            throw new ScpException(type + " '" + aToUri + "' is invalid. "
                                     + "The 'remoteToDir' attribute must "
                                     + "have syntax like the "
                                     + "following: user:password@host:/path"
                                     + " - the :password part is optional");
    	}
    } 

    /**
     * Changes the file name to the given name while receiving it,
     * only useful if receiving a single file.
     * @param aToUri a string representing the target of the copy.
     * @throws ScpException 
     * @since Ant 1.6.2
     */
    public void setLocalTofile(String aToUri) throws ScpException {
    	if (aToUri != null) {
            setToUri(aToUri);
            this.isToRemote = false;    		
    	}
    }

    /**
     * Changes the file name to the given name while sending it,
     * only useful if sending a single file.
     * @param aToUri a string representing the target of the copy.
     * @throws ScpException 
     * @since Ant 1.6.2
     */
    public void setRemoteTofile(String aToUri) throws ScpException {
    	if (aToUri != null) {
            validateRemoteUri("remoteToFile", aToUri);
            setToUri(aToUri);
            this.isToRemote = true;    		
    	}
    }

    /**
     * Setting this to true to use sftp protocol.
     *
     * @param yesOrNo if true sftp protocol will be used.
     */
    public void setSftp(boolean yesOrNo) {
        isSftp = yesOrNo;
    }

    /**
     * Initialize this task.
     * @throws ScpException on error
     */
    public void init() {       
        this.toUri = null;
        this.fromUri = null;        
    }

    /**
     * Execute this task.
     * @throws ScpException on error
     */
    public void execute() throws ScpException {
        if (toUri == null) {
            throw ScpException.exactlyOne(TO_ATTRS);
        }
        if (fromUri == null) {
            throw ScpException.exactlyOne(FROM_ATTRS, "one or more nested filesets");
        }
            if (isFromRemote && !isToRemote) {
            	try {
                	scpLogger.onStartDownload(fromUri, toUri);            		
            	} catch (Throwable t) {
            		logger.error(t.getMessage(), t);
            	}
                try {
					download(fromUri, toUri);
				} catch (JSchException e) {
					throw new ScpException(e);
				} catch (IOException e) {
					throw new ScpException(e);
				}
            	try {
                	scpLogger.onEndDownload(fromUri, toUri);            		
            	} catch (Throwable t) {
            		logger.error(t.getMessage(), t);
            	}
            } else if (!isFromRemote && isToRemote) {
            	try {
					from = new File(fromUri).getCanonicalFile();
				} catch (IOException e) {
					throw new ScpException(e);
				}
            	logger.info("from=" + from);

            	String wildcards = null;
            	if (from.isFile()) {
            		logger.info("File mode.");
	            	try {
	                	scpLogger.onStartUpload(1, 1, from, toUri);            		
	            	} catch (Throwable t) {
	            		logger.error(t.getMessage(), t);
	            	}
	                try {
						upload(from, toUri);
					} catch (IOException e) {
						throw new ScpException(e);
					} catch (JSchException e) {
						throw new ScpException(e);
					}                
	            	try {
	                	scpLogger.onEndUpload(1, 1, from, toUri);            		
	            	} catch (Throwable t) {
	            		logger.error(t.getMessage(), t);
	            	}		        	              		
            	} else if (from.isDirectory()) {
            		logger.info("Directory mode.");
            		wildcards = "*.*";

                	logger.info("wildcards=" + wildcards);
                	
                	FileFilter fileFilter = new WildcardFileFilter(wildcards);
                	File[] listOfFilesAndDirs = from.listFiles(fileFilter);
    		        logger.info("Found " + listOfFilesAndDirs.length + " files and directories.");
                	
                	Vector<File> listOfFiles = new Vector<File>(); 
                	for (int j=0; j<listOfFilesAndDirs.length; j++) {
                		if (listOfFilesAndDirs[j].isFile()) {
                			logger.info("listOfFilesAndDirs[" + j + "]=" + listOfFilesAndDirs[j]);
                			listOfFiles.add(listOfFilesAndDirs[j]);
                		}
                	}
                	int totalOfFilesFound = listOfFiles.size();
    		        logger.info("Found " + totalOfFilesFound + " files.");
    		        for (int j=0; j<totalOfFilesFound; j++) {
    		          File localFile = listOfFiles.get(j);
    	            	try {
    	                	scpLogger.onStartUpload(j+1, totalOfFilesFound, localFile, toUri);            		
    	            	} catch (Throwable t) {
    	            		logger.error(t.getMessage(), t);
    	            	}
    	                try {
							upload(localFile, toUri);
						} catch (IOException e) {
							throw new ScpException(e);
						} catch (JSchException e) {
							throw new ScpException(e);
						}                
    	            	try {
    	                	scpLogger.onEndUpload(j+1, totalOfFilesFound, localFile, toUri);            		
    	            	} catch (Throwable t) {
    	            		logger.error(t.getMessage(), t);
    	            	}		        	  
    		        }                	
            	} else if ((new File(fromUri).getName().indexOf("*") != -1) ||
            			   (new File(fromUri).getName().indexOf("?") != -1)) {
            		logger.info("Wildcards mode");
                	try {
						from = new File(fromUri).getParentFile().getCanonicalFile();
					} catch (IOException e) {
						throw new ScpException(e);
					}
                	logger.info("from=" + from);
                	
                	wildcards = new File(fromUri).getName();	
                	logger.info("wildcards=" + wildcards);
                	
                	this.current = new Directory(from, null);                	                
                	MakeTree mt = new MakeTree(this);
                	try {
						mt.searchDirectoryFile(from, wildcards, this.isRecursive);
					} catch (MakeTreeException e) {
						throw new ScpException(e);
					}
                	
                    // Folder folder = new Folder(from);
                    // folder.scan(wildcards);
                    
                	// this.current = new Directory(from, null);
                	// this.listOfDirectory = folder.toDirectory(this.current);
                    
            	    // List<File> files = FileListing.getFileListing(from);

            	    //print out all file names, in the the order of File.compareTo()                    
                    String file = parseUri(toUri);                    
                    Session session = null;
                    try {                        
                    	logger.info("listOfDirectory.size()=" + listOfDirectory.size());
                        if (!this.listOfDirectory.isEmpty()) {
                            session = openSession();
                            ScpToMessage message = null;
                            if (!isSftp) {
                                message = new ScpToMessage(getVerbose(), session, this.listOfDirectory, file);
                            } else {
                                message = new ScpToMessageBySftp(getVerbose(), session, this.listOfDirectory, file);
                            }
                            message.setChmodFile(this.chmodFile);
                            message.setChmodDirectory(this.chmodDirectory);
                            message.setScpLogger(this.scpLogger);
                            message.setLogListener(this);
                            message.execute();
                        }
                    } catch (JSchException e) {
    					throw new ScpException(e);
					} catch (IOException e) {
						throw new ScpException(e);
					} finally {
                        if (session != null) {
                            session.disconnect();
                        }
                    }
            	} else {
                    throw new ScpException(fromUri + " not valid!");
            	}            	            	
            } else if (isFromRemote && isToRemote) {
                throw new ScpException(
                    "Copying from a remote server to a remote server is not supported.");
            } else {
                throw new ScpException("'todir' and 'file' attributes "
                    + "must have syntax like the following: "
                    + "user:password@host:/path");
            }
    }

    private void download(String fromSshUri, String toPath) throws JSchException, IOException, ScpException {
        String file = parseUri(fromSshUri);

        Session session = null;
        try {
            session = openSession();
            ScpFromMessage message = null;
            if (!isSftp) {
                message = new ScpFromMessage(getVerbose(), session, file,
                                       new File(toPath),
                                       this.isRecursive,
                                       preserveLastModified);
            } else {
                message = new ScpFromMessageBySftp(getVerbose(), session, file,
                                             new File(toPath),
                                             this.isRecursive,
                                             preserveLastModified);
            }
            log("Receiving file: " + file);
            message.setLogListener(this);
            message.execute();
        } finally {
            if (session != null) {
                session.disconnect();
            }
        }
    }
   
    private void upload(File fromPath, String toSshUri) throws IOException, JSchException, ScpException {
        String file = parseUri(toSshUri);

        Session session = null;
        try {
            session = openSession();
            ScpToMessage message = null;
            if (!isSftp) {
                message = new ScpToMessage(getVerbose(), session,fromPath, file);
            } else {
                message = new ScpToMessageBySftp(getVerbose(), session, fromPath, file);
            }
            message.setChmodFile(this.chmodFile);
            message.setChmodDirectory(this.chmodDirectory);
            message.setLogListener(this);
            message.execute();
        } finally {
            if (session != null) {
                session.disconnect();
            }
        }
    }
        
    private String parseUri(String uri) throws ScpException {
    	logger.info("uri=" + uri);
        int indexOfAt = uri.indexOf('@');
        int indexOfColon = uri.indexOf(':');

        if (indexOfColon > -1 && indexOfColon < indexOfAt) {
            // user:password@host:/path notation
            // everything upto the last @ before the last : is considered
            // password. (so if the path contains an @ and a : it will not work)
            int indexOfCurrentAt = indexOfAt;
            int indexOfLastColon = uri.lastIndexOf(':');
            while (indexOfCurrentAt > -1 && indexOfCurrentAt < indexOfLastColon) {
                indexOfAt = indexOfCurrentAt;
                indexOfCurrentAt = uri.indexOf('@', indexOfCurrentAt + 1);
            }
            setUsername(uri.substring(0, indexOfColon));
            setPassword(uri.substring(indexOfColon + 1, indexOfAt));
        } else if (indexOfAt > -1) {
            // no password, will require keyfile
            setUsername(uri.substring(0, indexOfAt));
        } else {
            throw new ScpException("no username was given.  Can't authenticate."); 
        }

        int indexOfPath = uri.indexOf(':', indexOfAt + 1);
        if (indexOfPath == -1) {
            throw new ScpException("no remote path in " + uri);
        }

        setHost(uri.substring(indexOfAt + 1, indexOfPath));
        String remotePath = uri.substring(indexOfPath + 1);
                
        if ((getUserInfo().getPassword() == null) && 
        	(getUserInfo().getKeyfile() == null) &&
        	(getUserInfo().getPassphrase() == null) &&
        	(this.askPassword == true)) {
                
            	String pwd = Utility.inputString(this.getUserInfo().getName() + "@" + this.getHost() + "'s password:", null);
                if (pwd == null) {
                	throw new ScpException("neither password nor keyfile for user "
                            + getUserInfo().getName() + " has been "
                            + "given.  Can't authenticate.");            	
                } else {
            		setPassword(pwd);
                }
        } 
        /*
        if (getUserInfo().getPassword() == null
                && getUserInfo().getKeyfile() == null) {
                throw new ScpException("neither password nor keyfile for user "
                                         + getUserInfo().getName() + " has been "
                                         + "given.  Can't authenticate.");
        }
        */
        
        if (remotePath.equals("")) {
            remotePath = ".";
        }
        return remotePath;
    }

    private static boolean isRemoteUri(String uri) {
        boolean isRemote = true;
        int indexOfAt = uri.indexOf('@');
        if (indexOfAt < 0) {
            isRemote = false;
        }
        return isRemote;
    }

    private void setFromUri(String fromUri) throws ScpException {
        if (this.fromUri != null) {
            throw ScpException.exactlyOne(FROM_ATTRS);
        }
        this.fromUri = fromUri;
    }

    private void setToUri(String toUri) throws ScpException {
        if (this.toUri != null) {
            throw ScpException.exactlyOne(TO_ATTRS);
        }
        this.toUri = toUri;
    }

	
	public void log(String message) {
		logger.info(message);
	}

	public boolean isRecursive() {
		return isRecursive;
	}

	public void setRecursive(boolean isRecursive) {
		this.isRecursive = isRecursive;
	}

	public void onFileFound(File aFile) throws MakeTreeException {
		logger.info("Added file " + aFile.getName());		
        current.addFile(aFile);
	}

	public void onDirFound(File aDirectory) throws MakeTreeException {
		logger.info("Added directory " + from);			
		String path[] = current.getPath();
		for (int j=0; j<path.length; j++) {
			logger.info(path[j]);			
		} 
		
		// current.addDirectory(new Directory(new File(aDirectory.getName())));
        current = new Directory(aDirectory, current.getParent());
        listOfDirectory.add(current);
	}

	public boolean isAskPassword() {
		return askPassword;
	}

	public void setAskPassword(boolean askPassword) {
		this.askPassword = askPassword;
	}

	public int getNumberOfRetry() {
		return numberOfRetry;
	}

	public void setNumberOfRetry(int numberOfRetry) {
		this.numberOfRetry = numberOfRetry;
	}

	public String getChmodFile() {
		return chmodFile;
	}

	public void setChmodFile(String chmodFile) {
		this.chmodFile = chmodFile;
	}

	public String getChmodDirectory() {
		return chmodDirectory;
	}

	public void setChmodDirectory(String chmodDirectory) {
		this.chmodDirectory = chmodDirectory;
	}

	
}
