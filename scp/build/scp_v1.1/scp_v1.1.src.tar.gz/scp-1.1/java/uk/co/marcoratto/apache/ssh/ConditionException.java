package uk.co.marcoratto.apache.ssh;

public class ConditionException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8081682431340732511L;

	public ConditionException(String s) {
		super(s);
	}

	public ConditionException(String s, Exception e) {
		super(s, e);
	}

	public ConditionException(Exception e) {
		super(e);
	}

}
